# vm_observability

A Python library to monitor CPU, memory, disk, network, and process utilization of a VM.

## Installation

```bash
pip install vm_observability
